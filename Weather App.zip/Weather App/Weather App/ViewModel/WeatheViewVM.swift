//
//  WeatheViewVM.swift
//  Weather App
//
//  Created by Godohaldo Perez on 9/23/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

//move protocol to model
protocol WeatherViewVMDelegate:class{
    func updateLabels()
    func pushAlert(alert:UIAlertController)
}

class WeatherViewVM{
    var weather:CurrentWeather?
    weak var weatherViewController:WeatherViewVMDelegate?
    var isTempInC = true
    init (delegate:WeatherViewVMDelegate?){
        self.weatherViewController = delegate
    }
    
    func getLocation()->String?{
        return (weather?.name ?? "Unknown location") + ", " + (weather?.sys.country ?? "Somewhere")
    }
    func getTemp()->String?{
        guard let tempInK = weather?.main.temp else{
            return nil
        }
        guard isTempInC else{return getTempInF(tempInK: tempInK)}
        return getTempInC(tempInK: tempInK)
        
    }
    private func getTempInF(tempInK:Float)->String{
        let tempInF = Int(9*(tempInK - 273.15)/5 + 32)
        return "\(tempInF)℉"
    }
    private func getTempInC(tempInK:Float)->String{
        let tempInC = Int(tempInK - 273.15)
        return "\(tempInC)℃"
    }
    func getWeatherConditions()->String?{
        return weather?.weather[0].description//might need a arraylenght check here
    }
    func getCloudCover()->String?{
        guard let cloudCover = weather?.clouds.all else{return nil}
        return "\(cloudCover)%"
    }
    func getWind()->String?{
        guard let windSpeed = weather?.wind.speed else {return nil}
        guard let windDirection = weather?.wind.deg else {return nil}
        return "\(windSpeed)m/s, \(windDirection)°"
    }
    func getTimeStamp()->String?{
        guard let timeStamp = weather?.dt else {return nil }
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy' at 'HH:mm"

        let timeString = Date.init(timeIntervalSince1970: TimeInterval(timeStamp))
        return "Updated on: " + dateFormatter.string(from: timeString)
        
    }
    func getWeatherFromUserInput(){
    let alert = UIAlertController(title: "Enter Zipcode", message:"Enter the Zipcode of the place you want to know the weather of:",preferredStyle: .alert)
    alert.addTextField { (textField) in textField.placeholder = "00000,US"}
        let ok = UIAlertAction(title: "Ok", style: .default) {
            [unowned self] (action) in
            guard let zip = alert.textFields?[0].text else {return}
            self.getWeatherData(zipCode: zip)
        }
        let cancel = UIAlertAction(title: "Cancel", style: .cancel)
        alert.addAction(ok)
        alert.addAction(cancel)
        weatherViewController?.pushAlert(alert: alert)
        
    }
    
    func getWeatherData(zipCode:String){
        Networking.getForecast(zipCode: zipCode) {
            [unowned self](weather, error) in
            guard error == nil else{
                let alert = UIAlertController(title: "Error", message: "Could not find weather data", preferredStyle: .alert)
                let ok = UIAlertAction(title: "ok", style: .cancel)
                alert.addAction(ok)
                self.weatherViewController?.pushAlert(alert: alert)
                return
            }
            guard let currentWeather = weather else{return}
            self.weather = currentWeather
            self.weatherViewController?.updateLabels()
        }
    }
    
    
}

