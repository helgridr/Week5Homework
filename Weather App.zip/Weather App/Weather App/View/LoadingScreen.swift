//
//  LoadingScreen.swift
//  Weather App
//
//  Created by Godohaldo Perez on 9/26/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import UIKit

//followed a tutorial for this on medium.com
class LoadingScreen: UIView {
    var shouldSetConstraints = true
    var label:UILabel!
    
    override init(frame: CGRect){
        super.init(frame: frame)
        self.backgroundColor = UIColor.cyan
        label = UILabel(frame: CGRect(x: 10, y: 10, width: 100, height: 20))
        label.textColor = UIColor.black
        label.text = "Divining user's location"
        label.sizeToFit()
    }
    
    required init?(coder aDecoder: NSCoder) {
       super.init(coder: aDecoder)

    }
    
    override func updateConstraints() {
        if shouldSetConstraints {
           //constraints!
            shouldSetConstraints = false
        }
        super.updateConstraints()
    }
    
    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
