//
//  Constants.swift
//  Weather App
//
//  Created by Godohaldo Perez on 9/21/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation

class Constants{
    //static let kBaseUrlZip = "https://api.openweathermap.org/data/2.5/forecast?zip="
    static let kBaseUrlZip = "https://api.openweathermap.org/data/2.5/weather?zip="
    static let kApiKey = "&APPID=b1ed09864daece5c6cfd9a26c3c7dd4b"
}
