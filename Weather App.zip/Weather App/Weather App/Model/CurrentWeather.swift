//
//  CurrentWeather.swift
//  Weather App
//
//  Created by Godohaldo Perez on 9/23/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation

struct CurrentWeather:Codable{
    let main: TempPressureNHumidity
    let weather:[Weather]
    let clouds: Clouds
    let wind: Wind
    let dt:Int
    let sys:CountryData
    let name:String

    
    struct TempPressureNHumidity:Codable {
        let temp:Float
        let pressure:Float
        let humidity:Float
    }
    struct Weather:Codable{
        let main:String
        let description:String
        let icon:String
    }
    struct Clouds:Codable{
        let all: Float
    }
    struct Wind:Codable{
        let speed:Float
        let deg:Float
    }
    struct CountryData:Codable{
        let country: String
        let sunrise: Int
        let sunset: Int
    }
}
