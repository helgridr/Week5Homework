//
//  Networking.swift
//  Weather App
//
//  Created by Godohaldo Perez on 9/21/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation

class Networking{
    static func getForecast(zipCode:String,completion:@escaping(CurrentWeather?,NetworkError?)->()){
        let url = Constants.kBaseUrlZip + zipCode + Constants.kApiKey
        guard let myUrl = URL(string:url)else{
            let networkError = NetworkError.apiFailedWithAFunnyUrl(url)
            completion(nil,networkError)
            return
        }
        let session = URLSession.shared
        let task = session.dataTask(with: myUrl){
            (data,response,error) in
            guard  error==nil else {
                let networkError = NetworkError.apiDidFailWithError(error!.localizedDescription)
                completion(nil,networkError)
                return
            }
            guard let httpResponse = response as? HTTPURLResponse else{
                let networkError = NetworkError.apiRespondedWithMalformedHTTPResponse
                completion(nil,networkError)
                return
            }
            guard httpResponse.statusCode == 200 else{
                let networkError = NetworkError.apiRespondedWithAnHTTPFailureCode(httpResponse.statusCode)
                completion(nil,networkError)
                return
            }
            guard let data = data else{
                    let networkError = NetworkError.apiRespondedWithMalformedData
                    completion(nil,networkError)
                    return
            }
            do{
                let jsonDecoder = JSONDecoder()
                let weather = try jsonDecoder.decode(CurrentWeather.self, from: data)
                completion(weather, nil)
            }catch{
                print("error in decoder")
            }
            
        }
        task.resume()
    }
}
