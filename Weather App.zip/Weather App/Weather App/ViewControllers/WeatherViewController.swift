//
//  ViewController.swift
//  Weather App
//
//  Created by Godohaldo Perez on 9/21/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import UIKit
import Foundation
import CoreLocation

//to do: add images, ad loading screen, add weather for city functionality, sort errors
class WeatherViewController: UIViewController {
    
    @IBOutlet weak var location: UILabel!
    @IBOutlet weak var temperature: UILabel!
    @IBOutlet weak var weather: UILabel!
    @IBOutlet weak var cloudCover: UILabel!
    @IBOutlet weak var wind: UILabel!
    @IBOutlet weak var timeStamp: UILabel!

    

    lazy var viewModel = WeatherViewVM(delegate: self)
    var locationManager :CLLocationManager?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let delegate = UIApplication.shared.delegate as! AppDelegate//this force unwrap is fine
        self.locationManager = delegate.locationManager
        locationManager?.delegate = self
        
        //loading Screen
        /*let loadingScreen = LoadingScreen(frame: UIScreen.main.bounds)
        self.view.addSubview(loadingScreen)*/
        //ran out of time to make a loading screen work.
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 10) {
            self.locationManager?.requestLocation()
        }
        
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func getWeatherFromZip(_ sender: Any) {
        viewModel.getWeatherFromUserInput()
    }
    @IBAction func switchTemp(_ sender: Any) {
        viewModel.isTempInC = !viewModel.isTempInC
        temperature.text = viewModel.getTemp()
    }
    @IBAction func getWeatherForCurrentLocation(_ sender: Any) {
        locationManager?.requestLocation()
    }
    

}

extension WeatherViewController:WeatherViewVMDelegate{
    func updateLabels(){
        DispatchQueue.main.async {
            self.location.text = self.viewModel.getLocation()
            //self.location.sizeToFit()
            self.temperature.text = self.viewModel.getTemp()
            //self.temperature.sizeToFit()
            self.weather.text = self.viewModel.getWeatherConditions()
            //self.weather.sizeToFit()
            self.cloudCover.text = self.viewModel.getCloudCover()
            //self.cloudCover.sizeToFit()
            self.wind.text = self.viewModel.getWind()
            //self.wind.sizeToFit()
            self.timeStamp.text = self.viewModel.getTimeStamp()
            //self.timeStamp.sizeToFit()
        }

    }
    func pushAlert(alert:UIAlertController){
        self.present(alert,animated: true)
    }
}
extension WeatherViewController:CLLocationManagerDelegate{
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations.last ?? "Not able to spy on you!")
        guard let currentLocation = locations.last else {return}
        let geoCoder = CLGeocoder()
        geoCoder.reverseGeocodeLocation(currentLocation) { (location, error) in
            guard error == nil else{
                return
            }
            guard let zip = location?.last?.postalCode else {return}
            guard let country = location?.last?.isoCountryCode else{
                return
            }
            self.viewModel.getWeatherData(zipCode: zip + "," + country)
        }
        //convert location to zip
        //self.centerInLocation(location: (locations.last?.coordinate)!)
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
}
