//
//  Ingredients.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/19/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

enum Toppings: String,Codable{
    case jalapenos = "jalapenos"
    case pineapple = "pineapple"
    case parmesanParsley = "parmesan parsley"
    case mozarellaCheese = "mozzarella cheese"
    case alfredoSauce = "alredo sauce"
    case lettuce = "lettuce"
    case dicedWhiteOnion = "diced white onions"
    case artichokes = "artichokes"
    case chicken = "chicken"
    case canadianBacon = "canadian bacon"
    case freshBasil = "fresh basil"
    case rosaGrandePepperoni = "rosa grande pepperoni"
    case sausage = "sausage"
    case garlicBasilOil = "garlic basil oil"
    case roastedRedPepper = "roasted red pepper"
    case onion = "onions"
    case carmelizedRedOnion = "carmelized red onion"
    case pepperoni = "pepperoni"
    case italianSausage = "italian sausage"
    case bacon = "bacon"
    case mushrooms = "mushrooms"
    case fourCheese = "four cheese"
    case greenPeppers = "green peppers"
    case beef = "beef"
    case blackOlives = "black olives"
    case dicedTomato = "diced tomatoes"
    case fetaCheese = "feta cheese"
    case hotPeppers = "hot peppers"
    case anchovies = "anchovies"
    case slicedRomaTomatoes = "sliced roma tomatoes"
    case ham = "ham"
    case slicedBreadedChickenBreast = "sliced breaded chicken breast"
    case cheddarCheese = "cheddar cheese"
    case salami = "salami"
    case giantPepperoni = "giant pepperoni"
    case refriedBean = "refried beans"
    
    static let allValues = [jalapenos,pineapple,parmesanParsley,mozarellaCheese,alfredoSauce,lettuce,dicedWhiteOnion,artichokes,chicken,canadianBacon,freshBasil,rosaGrandePepperoni,sausage,garlicBasilOil,roastedRedPepper,onion,carmelizedRedOnion,pepperoni,italianSausage,bacon,mushrooms,fourCheese,greenPeppers,beef,blackOlives,dicedTomato,fetaCheese,hotPeppers,anchovies,slicedRomaTomatoes,ham,slicedBreadedChickenBreast,cheddarCheese,salami,giantPepperoni,refriedBean]

}
