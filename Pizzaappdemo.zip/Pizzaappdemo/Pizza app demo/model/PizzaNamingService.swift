//
//  PizzaNamingService.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/24/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation

class PizzaNamingService{
    static func getPizzaName(pizza:MyPizza)->String{
        guard let ingredientStrings = pizza.ingredients as? Set<MyIngredient> else {return "pizza"}
        let ingredients = ingredientStrings.map{$0.name ?? ""}
        switch ingredients.count{
        case 1:
            return ingredients[0] + " pizza"
        case 2:
            return ingredients[0] + " and " + ingredients[1] + " pizza"
        default:
            return "\(ingredients.count) ingredient pizza"
        }
    }
    static func getPizzaName(pizza:Pizza)->String{
        let ingredients = pizza.toppings.map{$0.rawValue}
        switch ingredients.count{
        case 1:
            return ingredients[0] + " pizza"
        case 2:
            return ingredients[0] + " and " + ingredients[1] + " pizza"
        default:
            return "\(ingredients.count) ingredient pizza"
        }
    }
    
}
