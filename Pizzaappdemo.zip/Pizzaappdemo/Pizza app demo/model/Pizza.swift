//
//  Pizza.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/22/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
struct Pizza:Codable,Hashable{
    static func ==(lhs: Pizza, rhs: Pizza) -> Bool {
        return lhs.toppings == rhs.toppings
        //return lhs.sortedIngredients() == rhs.sortedIngredients()
    }
    var toppings:Set<Toppings>
    init (toppings:[Toppings]){
        self.toppings = Set(toppings)//only 3 pizza in the json repeat ingredients and they are all unique, so ifelt justified in just using set.
    }
    var hashValue: Int{
        return toppings.map{$0.hashValue}.reduce(0){$0 + $1}
    }
    
    /*
     private func sortIngredients(unorderedToppings:[Toppings])->[Toppings]{
     return unorderedToppings.sorted{$0.rawValue < $1.rawValue}
     }*/
    
}
