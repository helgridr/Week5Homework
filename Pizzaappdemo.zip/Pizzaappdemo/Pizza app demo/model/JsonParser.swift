//
//  JsonParser.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/21/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation

class JsonParser{
    static func parse(completion:([Pizza]?,ParserError?)->()){
        let path = Bundle.main.bundlePath + "/assignment.json"
        guard let json = FileManager.default.contents(atPath: path) else {
            completion(nil,ParserError.error)
            return}
        
        do{
            let jsonDecoder = JSONDecoder()
            let pizzaList = try jsonDecoder.decode([Pizza].self, from: json)

            var pizzaCount:[Pizza:Int] = [:]
            pizzaList.forEach{
                if let count = pizzaCount[$0]{
                    pizzaCount[$0] = count + 1
                }else{
                    pizzaCount[$0] = 1
                }
            }

            let sorted = pizzaCount.sorted(by: {pizza1, pizza2 in
                pizza1.value > pizza2.value
            })
            completion(sorted.map{$0.key},nil)
        }catch{
            completion(nil,ParserError.error)
        }
        
    }
}
