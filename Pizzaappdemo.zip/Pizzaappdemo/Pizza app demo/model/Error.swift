//
//  Enums.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/21/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation

enum NetworkError{
    case apiDidFailWithError(String)
    case apiRespondedWithMalformedHTTPResponse
    case apiRespondedWithAnHTTPFailureCode(Int)
    case apiFailedParsingJSON(String)
    case apiRespondedWithMalformedData
    case dataIsNotAnImage
    case apiFoundNoSpeciesUrl
    case apiFailedConvertingJSONToDictionary
    case apiFailedParsingDictionaries
    case apiFailedWithAFunnyUrl(String)
}
enum ParserError:Error{
    case error
}
enum DBError:Error{
    case error
}
