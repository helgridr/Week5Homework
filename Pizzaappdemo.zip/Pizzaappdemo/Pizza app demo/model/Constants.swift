//
//  Constants.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/21/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation

class Constants{
    static let jsonUrl = "https://raw.githubusercontent.com/helgridr/PizzaAppFIles/master/assignment.json"
}
