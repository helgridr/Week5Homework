//
//  DatabaseManager.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/23/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import CoreData
class DatabaseManager{
    static func getPurchaseHistory(completion:([MyPizza]?,DBError?)->()){
        guard let context = AppDelegate.viewContext else {
            completion(nil,DBError.error)
            return}
        let fetchRequest:NSFetchRequest<MyPizza> = MyPizza.fetchRequest()
        let sortDescriptor = NSSortDescriptor(key: "date", ascending: false)
        fetchRequest.sortDescriptors = [sortDescriptor]
        do {
            let history = try context.fetch(fetchRequest)
            //completion goes here?
            completion(history,nil)
        } catch{
            completion(nil,DBError.error)
        }
        //unfinished
    }
    
    static func addNewPurchase(ingredients:[String]){
        guard let context = AppDelegate.viewContext else {return}
        
        let pizza = MyPizza(context: context)
        pizza.date = Date()
        for topping in ingredients{
            if let pizzaContext = pizza.managedObjectContext{
                let newIngredient = MyIngredient(context: pizzaContext)
                newIngredient.name = topping
                pizza.addToIngredients(newIngredient)
            }
        }
        do{
            try context.save()
        } catch let error {
            print("FUCK, you did something wrong: \(error)")
        }
    }
    
    static func deletePurchase(pizza:MyPizza){
        guard let context = pizza.managedObjectContext else {return}
        context.delete(pizza)
        do{
            try context.save()
            //names.append(person)
        } catch let error {
            print("FUCK, you did something wrong: \(error)")
        }

    }
    
}

