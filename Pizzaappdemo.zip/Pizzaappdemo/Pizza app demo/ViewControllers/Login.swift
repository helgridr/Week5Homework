//
//  Login.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/25/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

class LoginViewController:UIViewController{
    
    @IBOutlet weak var username:UITextField!
    @IBOutlet weak var password:UITextField!
    @IBOutlet weak var toggle: UISegmentedControl!
    
    lazy var viewModel = LoginVM(delegate: self )
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    override func didReceiveMemoryWarning() {
        
    }
    @IBAction func login(_ sender: Any) {
        guard let user = username.text else {return}
        guard let pass = password.text else {return}
        if toggle.selectedSegmentIndex == 0{
            viewModel.login(username: user, password: pass)
        }else{
            viewModel.signUp(username: user, password: pass)
        }
        //viewModel.login(username:String,password:String)
    }
    
}
extension LoginViewController:LoginVMDelegate{
    func presentAlert(_ alert:UIAlertController){
        self.present(alert, animated: true)
    }
    func segue(){
        self.performSegue(withIdentifier: "ToMainView", sender: self)
        // not sure how to dismiss the current view controller
    }
}
