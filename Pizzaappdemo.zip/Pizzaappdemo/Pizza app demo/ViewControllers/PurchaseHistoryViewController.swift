//
//  PurchaseHistoryViewController.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/19/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

class PurchaseHistoryViewController: UITableViewController {
    
    lazy var viewModel = PurchaseHistoryVM(delegate:self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.loadOrderHistory()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Purchase History"
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getNumberOfRows()
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "PurchaseHistoryCell") else {fatalError("Boom! Your cell exploded")}
        //change the cell to custom later
        cell.layer.cornerRadius = 10
        cell.textLabel?.text = viewModel.getPizzaTitle(index:indexPath.row)
        cell.detailTextLabel?.text = viewModel.getPizzaDetail(index:indexPath.row)
        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let alert = viewModel.deleteSelectedItem(index:indexPath.row)
        self.present(alert, animated: true)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}

extension PurchaseHistoryViewController:PurchaseHistoryVMDelegate{
    func reloadData(){
        self.tableView.reloadData()//not async son no dispatchqeue main?  this might change.
    }
}
