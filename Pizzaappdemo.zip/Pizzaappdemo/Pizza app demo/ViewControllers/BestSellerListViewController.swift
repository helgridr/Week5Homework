//
//  ViewController.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/19/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import UIKit


//this app can still be much improved, but I dont have time to do it 
class BestSellerListViewController: UITableViewController {

    lazy var viewModel = BestSellerListVM(delegate:self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
        // Do any additional setup after loading the view, typically from a nib.
        viewModel.loadBestSellers()//implement the spinny thing?
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //got some code for the toolbar from stackoverflow
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setToolbarHidden(false, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setToolbarHidden(true, animated: true)
    }

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Bestseller Pizzas"
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getNumberOfRows()
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "BestSellerCell") else {fatalError("Boom! Your cell exploded")}
        //change the cell to custom later
        cell.layer.cornerRadius = 10
        cell.textLabel?.text = viewModel.getPizzaTitle(index:indexPath.row)
        cell.detailTextLabel?.text = viewModel.getPizzaDetail(index:indexPath.row)
        return cell
    }
    
    @IBAction func show5BestSellers(_ sender: Any) {
        viewModel.changeNumberOfRows(number:5)
    }
    
    @IBAction func show20BestSellers(_ sender: Any) {
        viewModel.changeNumberOfRows(number:20)
    }
    @IBAction func show100BestSellers(_ sender: Any) {
        viewModel.changeNumberOfRows(number:100)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let identifier = segue.identifier else {return}
        //guard identifier == "ToListViewAgain" else {return}
        guard let indexPath = self.tableView.indexPathForSelectedRow else {return}
        switch identifier {
        case "ToBestSellerDetail":
            guard let nextView = segue.destination as? BestSellerDetailViewController else {return}
            nextView.viewModel.loadToppingsToVM(pizza: self.viewModel.bestSellers[indexPath.row]) 
        default:
            return
        }
        
        self.tableView.deselectRow(at: indexPath, animated: true)
    }

}
extension BestSellerListViewController:BestSellerListVMDelegate{
    func reloadData(){
        self.tableView.reloadData()//not async son no dispatchqeue main?  this might change.
    }
}

