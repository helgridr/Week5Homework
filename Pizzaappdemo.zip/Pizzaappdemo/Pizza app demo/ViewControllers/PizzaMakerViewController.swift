//
//  PizzaMakerViewController.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/19/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

class PizzaMakerViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var pizzaImage:UIImageView!
    @IBOutlet weak var selectedIngredientsTableView:UITableView!
    @IBOutlet weak var allIngredientsTableView:UITableView!
    
    lazy var viewModel = PizzaMakerVM(delegate: self)
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        selectedIngredientsTableView.dataSource = self
        selectedIngredientsTableView.delegate = self
        selectedIngredientsTableView.allowsSelection = false
        allIngredientsTableView.dataSource = self
        allIngredientsTableView.delegate = self
        pizzaImage.image = viewModel.loadImage()
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setToolbarHidden(false, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setToolbarHidden(true, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if tableView == self.allIngredientsTableView{
            return "Toppings"
        }else{
            return "Currently on pizza"
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.allIngredientsTableView{
             return viewModel.getNumberOfRowsForAllIngredients()
        }else{
             return viewModel.getNumberOfRowsForCurrentlyInPizza()
        }
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //dunno how to move this if statement to the vi
        if tableView == self.allIngredientsTableView{
            guard let cell = self.allIngredientsTableView.dequeueReusableCell(withIdentifier: "AllIngredientsCell") else {fatalError("Boom! Your cell exploded")}
            //change the cell to custom later
            cell.textLabel?.text = viewModel.getPizzaIngredientForAllIngredients(index:indexPath.row)
            return cell
        }else{
            guard let cell = self.selectedIngredientsTableView.dequeueReusableCell(withIdentifier: "IngredientsInPizzaCell") else {fatalError("Boom! Your cell exploded")}
            //change the cell to custom later
            cell.textLabel?.text = viewModel.getPizzaIngredientForCurrentlyInPizza(index:indexPath.row)
            return cell
        }

        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let possibleAlert = viewModel.addIngredient(index:indexPath.row)
        tableView.deselectRow(at: indexPath, animated: true)
        guard let alert = possibleAlert else {return}
        self.present(alert,animated: true)
        
    }
    
    @IBAction func clearPizza(_ sender: Any) {
        let alert = viewModel.clearPizza()
        self.present(alert, animated: true)
    }
    
    @IBAction func placeOrder(_ sender: Any) {
        let alert = viewModel.confirmOrder()
        self.present(alert, animated: true)
    }
}

extension PizzaMakerViewController:PizzaMakerVMDelegate{
    func reloadCurrentlyInPizza(){
        DispatchQueue.main.async {
            self.selectedIngredientsTableView.reloadData()
        }
        
    }
    func presentAlert(_ alert:UIAlertController){
        self.present(alert, animated: true)
    }
}
