//
//  BestSellerDetailViewController.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/19/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

class BestSellerDetailViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var pizzaImage:UIImageView!
    @IBOutlet weak var tableView:UITableView!
    
    lazy var viewModel = BestSellerDetailVM(delegate:self)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        pizzaImage.image = viewModel.loadImage()
        tableView.allowsSelection = false
        // Do any additional setup after loading the view, typically from a nib.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setToolbarHidden(false, animated: true)
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.navigationController?.setToolbarHidden(true, animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Ingredients"
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getNumberOfRows()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = self.tableView.dequeueReusableCell(withIdentifier: "BestSellerDetailCell") else {fatalError("Boom! Your cell exploded")}
        //change the cell to custom later
        cell.layer.cornerRadius = 10
        cell.textLabel?.text = viewModel.getPizzaIngredient(index:indexPath.row)
        return cell
    }

    @IBAction func orderPizza(_ sender: Any) {
        let alert = viewModel.confirmOrder()
        self.present(alert, animated: true)
        
        //segway
    }
    
    
    
}
extension BestSellerDetailViewController:BestSellerDetailVMDelegate{
    func presentAlert(_ alert:UIAlertController){
        self.present(alert, animated: true)
    }
}
