//
//  Alerts.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/24/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

class Alerts{
    static func createSimpleAlert(title: String, message:String)->UIAlertController{
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "ok", style: .cancel)
        alert.addAction(ok)
        return alert
    }
    static func createAlert(title:String,message:String,completion:(()->())? = nil)->UIAlertController{
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        if let _ = completion {
            let no = UIAlertAction(title: "cancel", style: .cancel)
            
            alert.addAction(no)
        }
        
        let ok = UIAlertAction(title: "confirm", style: .default){
            alert in
            completion?()
        }
        alert.addAction(ok)

        return alert
    }
}
