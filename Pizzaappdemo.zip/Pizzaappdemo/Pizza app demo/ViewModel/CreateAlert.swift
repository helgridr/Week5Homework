//
//  CreateNotification.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/19/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit
class CreateAlert{
    static func createAlert(string:String)->UIAlertController{
        let alert = UIAlertController(title: "Result", message: string, preferredStyle: .alert)
        let ok = UIAlertAction(title: "ok", style: .cancel)
        alert.addAction(ok)
        return alert
    }
}
