//
//  LoginVM.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/25/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import FirebaseAuth

protocol LoginVMDelegate:class{
    func presentAlert(_ alert:UIAlertController)
    func segue()
}

class LoginVM{
    weak var viewController:LoginVMDelegate?
    init(delegate:LoginVMDelegate){
        self.viewController = delegate
    }
    func login(username:String,password:String){
        Auth.auth().signIn(withEmail: username, password: password) { [unowned self] (user, error) in
            guard error == nil else {
                let alert = Alerts.createSimpleAlert(title: "Error", message: "Unsuccessful sing in. Please try again")
                self.viewController?.presentAlert(alert)
                return}
            guard user != nil else {
                let alert = Alerts.createSimpleAlert(title: "Error", message: "Unsuccessful sing in. Please try again")
                self.viewController?.presentAlert(alert)
                return}
            //login succesfull
            self.viewController?.segue()
        }
    }
    func signUp(username:String,password:String){
        Auth.auth().createUser(withEmail: username, password: password) { [unowned self] (user, error) in
            guard error == nil else {
                let alert = Alerts.createSimpleAlert(title: "Error", message: "Unsuccessful sing in. Please try again")
                self.viewController?.presentAlert(alert)
                return}
            guard user != nil else {
                let alert = Alerts.createSimpleAlert(title: "Error", message: "Unsuccessful sing in. Please try again")
                self.viewController?.presentAlert(alert)
                return}
            let alert = Alerts.createSimpleAlert(title: "Success!", message: "You have successfully signed up! You can now log in.")
            self.viewController?.presentAlert(alert)
        }
    }
}
