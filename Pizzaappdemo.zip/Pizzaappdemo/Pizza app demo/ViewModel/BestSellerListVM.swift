//
//  BestSellerListVM.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/19/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation

protocol BestSellerListVMDelegate:class{
    func reloadData()
}

class BestSellerListVM{
    var bestSellers: [Pizza] = []
    var maxNumberOfRows = 20
    weak var viewController:BestSellerListVMDelegate?
    
    init (delegate: BestSellerListVMDelegate){
        self.viewController = delegate
    }
    
    func getNumberOfRows()->Int{
    return bestSellers.count <= maxNumberOfRows ? bestSellers.count : maxNumberOfRows
    }
    
    func getPizzaTitle(index:Int)->String{
        return PizzaNamingService.getPizzaName(pizza: bestSellers[index])
    }
    
    func getPizzaDetail(index:Int)->String{
        return ""
    }
    func changeNumberOfRows(number:Int){
        guard number != maxNumberOfRows else{return}
        maxNumberOfRows = number
        viewController?.reloadData()
    }
    func loadBestSellers(){
        JsonParser.parse{[weak self](pizzaList,error) in
            guard error == nil else {return}//handle error
            guard let list = pizzaList else {return}//handle error
            self?.bestSellers = list
            //reload data?
            
        }
    }
    
}
