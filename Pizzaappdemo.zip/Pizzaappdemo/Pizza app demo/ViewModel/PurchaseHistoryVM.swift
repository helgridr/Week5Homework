//
//  PurchaseHistoryVM.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/19/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import CoreData
import UIKit
protocol PurchaseHistoryVMDelegate:class{
    func reloadData()
}

class PurchaseHistoryVM{
    var purchaseHistory:[MyPizza] = []
    
    weak var viewController:PurchaseHistoryVMDelegate?
    
    init (delegate: PurchaseHistoryVMDelegate){
        self.viewController = delegate
    }
    
    func getNumberOfRows()->Int{
        return purchaseHistory.count
    }
    
    func getPizzaTitle(index:Int)->String{
        return PizzaNamingService.getPizzaName(pizza: purchaseHistory[index])
    }
    
    func getPizzaDetail(index:Int)->String{
        guard let date = purchaseHistory[index].date else {return "no date"}
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy' at 'HH:mm"
        return dateFormatter.string(from: date)
    }
    
    func loadOrderHistory(){
        DatabaseManager.getPurchaseHistory{
            [weak self](history, error) in
            guard error == nil else{return}
            guard let history = history else{return}
            self?.purchaseHistory=history
            self?.viewController?.reloadData()
        }
    }
    func deleteSelectedItem(index:Int)->UIAlertController{
        return Alerts.createAlert(title: "Delete Selected Item", message: "Are you sure you want to delete the selected item?  This cannot be undone.") {
            [weak self] in
            DatabaseManager.deletePurchase(pizza: self?.purchaseHistory[index] ?? MyPizza())
            self?.loadOrderHistory()
        }
        
    }
}
