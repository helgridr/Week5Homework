//
//  PizzaMakerVM.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/19/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit

protocol PizzaMakerVMDelegate:class {
    func reloadCurrentlyInPizza()
    func presentAlert(_ alert:UIAlertController)
}
class PizzaMakerVM{
    weak var viewController:PizzaMakerVMDelegate?
    var selectedIngredients:[Toppings] = []

    init(delegate:PizzaMakerVMDelegate){
        self.viewController = delegate
    }
    
    func getNumberOfRowsForAllIngredients()->Int{
        return Toppings.allValues.count
    }
    func getNumberOfRowsForCurrentlyInPizza()->Int{
        return selectedIngredients.count
    }
    func getPizzaIngredientForAllIngredients(index:Int)->String{
        return Toppings.allValues[index].rawValue
    }
    func getPizzaIngredientForCurrentlyInPizza(index:Int)->String{
        return selectedIngredients[index].rawValue
    }
    func loadImage()->UIImage?{
        let image = #imageLiteral(resourceName: "Pizza-Pepperoni")
        return image
        //network call for real image
    }
    func addIngredient(index:Int)->UIAlertController?{
        //ned to perform checks before adding ingredient
        guard selectedIngredients.count < 10 else{
            let alert = Alerts.createSimpleAlert(title: "Maximum Toppings", message: "You cant add any more toppings")
            return alert
        }
        let ingredient = Toppings.allValues[index]
        guard (selectedIngredients.filter{$0 == ingredient}.count) <= 1 else {//filter also seems fucky. maybe my computer is fucky?
            let alert = Alerts.createAlert(title: "Same Topping Overload!", message: "You have tried to add too much \(ingredient).  Adding more will have little effect on the resulting pizza.  Do you whish to proceed anyways?", completion: {
                [weak self] in
                self?.sudoAddIngredient(ingredient: ingredient)
            })
            return alert
        }
        selectedIngredients.append(ingredient)
        viewController?.reloadCurrentlyInPizza()
        return nil
        //update view
    }
    private func sudoAddIngredient(ingredient: Toppings){
        selectedIngredients.append(ingredient)
        viewController?.reloadCurrentlyInPizza()
    }
    func clearPizza()->UIAlertController{
        guard !selectedIngredients.isEmpty else {
            let alert = Alerts.createSimpleAlert(title: "Invalid Command", message: "You haven't chosen any toppings yet...")
            return alert
        }
        let alert = Alerts.createAlert(title: "Clear Order", message: "Are you sure you want to delete your current pizza?  This process is irreversible.") {
            [weak self] in
            self?.selectedIngredients = []
            self?.viewController?.reloadCurrentlyInPizza()
        }
        return alert
    }
    func confirmOrder()->UIAlertController{
        let ingredients = selectedIngredients.map{$0.rawValue}
        guard !ingredients.isEmpty else {
            let alert = Alerts.createSimpleAlert(title: "Invalid Order", message: "You haven't chosen any toppings yet...")
            return alert
        }
        let alert = Alerts.createAlert(title:"Confirm Purchase", message: "Order this pizza?") {
            [weak self] in
            DatabaseManager.addNewPurchase(ingredients: ingredients)
            self?.selectedIngredients = []
            self?.viewController?.reloadCurrentlyInPizza()
            let alert = Alerts.createSimpleAlert(title: "Order Confirmed", message: "Your order has been processed")
            self?.viewController?.presentAlert(alert)//dismiss view?
        }
        return alert
    }
    
}
