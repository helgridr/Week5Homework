//
//  BestSellerDetailVM.swift
//  Pizza app demo
//
//  Created by Godohaldo Perez on 9/19/17.
//  Copyright © 2017 Godohaldo Perez. All rights reserved.
//

import Foundation
import UIKit
protocol BestSellerDetailVMDelegate:class{
    func presentAlert(_ alert:UIAlertController)
}

class BestSellerDetailVM{
    weak var viewController:BestSellerDetailVMDelegate?
    var ingredientList:[Toppings]?//move this to pizza?
    
    init(delegate:BestSellerDetailVMDelegate){
        self.viewController = delegate
    }
    func loadToppingsToVM(pizza:Pizza){
        ingredientList = Array(pizza.toppings)
    }
    
    func getNumberOfRows()->Int{
        return (ingredientList?.count) ?? 0
    }
    
    func getPizzaIngredient(index:Int)->String{
        return ingredientList?[index].rawValue ?? "Ingredients not found"
    }
    
    func loadImage()->UIImage?{
        let image = #imageLiteral(resourceName: "Pizza-Pepperoni")
        return image
        //network call for real image
    }
    
    func getToppingsAsStrings()->[String]{
        return ingredientList?.map{$0.rawValue} ?? []//flatmap seems fucky in the new xcode
    }
    
    func confirmOrder()->UIAlertController{
        let ingredients = getToppingsAsStrings()
        guard !ingredients.isEmpty else {
            let alert = Alerts.createSimpleAlert(title: "Invalid Order", message: "You haven't chosen any toppings yet...")
            return alert
        }
        let alert = Alerts.createAlert(title:"Confirm Purchase", message: "Order this pizza?") {
            [weak self]  in
            DatabaseManager.addNewPurchase(ingredients: ingredients)
            let alert = Alerts.createSimpleAlert(title: "Order Confirmed", message: "Your order has been processed")
            self?.viewController?.presentAlert(alert)//dismiss view?
        }
        return alert
    }
}
